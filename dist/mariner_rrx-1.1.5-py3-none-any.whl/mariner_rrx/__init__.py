#encoding:utf-8
#!/usr/bin/env python3
import mariner_rrx.mar
__version__ = mariner_rrx.mar.__version__
# 版本号改我！！！
import mariner_rrx.build
import mariner_rrx.get
import mariner_rrx.install
import mariner_rrx.uninstall
import mariner_rrx.upgrade